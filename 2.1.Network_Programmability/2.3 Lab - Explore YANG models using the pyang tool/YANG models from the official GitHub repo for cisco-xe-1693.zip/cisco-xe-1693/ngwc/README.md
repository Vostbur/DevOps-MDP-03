## Model Variations

A small number of YANG models supported in IOS-XE 16.9.3 has a few differences between the platforms for which the deviation files have been created. If you are working with switching platform, you should copy the deviation files from this directory into your working directory and use them. If you retrieve models directly from a device, you will get the correct set of models and deviations.
